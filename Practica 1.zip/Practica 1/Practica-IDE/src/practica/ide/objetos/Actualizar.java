/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Actualizar extends Consultas {
    private List<Asignaciones> asignaciones;
    private List<Filtros> filtros;
    private Filtros filt;
    
    public Actualizar(List<Asignaciones> asignaciones, List<Filtros> filtros, String nombreConsulta, String ubicacionConsulta) {
        super(nombreConsulta, ubicacionConsulta);
        this.asignaciones = asignaciones;
        this.filtros = filtros;
    }

    public Filtros getFilt() {
        return filt;
    }

    public void setFilt(Filtros filt) {
        this.filt = filt;
    }

   

    public List<Asignaciones> getAsignaciones() {
        return asignaciones;
    }

    public void setAsignaciones(List<Asignaciones> asignaciones) {
        this.asignaciones = asignaciones;
    }

    public List<Filtros> getFiltros() {
        return filtros;
    }

    public void setFiltros(List<Filtros> filtros) {
        this.filtros = filtros;
    }
}
