/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

/**
 *
 * @author USUARIO
 */
public class Nodo {
    private String nombre;
    private String ubicacion;
    private boolean archivo;
    private List<Nodo> archivosYCarpetas;
    private List<DefaultMutableTreeNode> nodos;
    
    public Nodo(String nombre, boolean archivo) {
        this.archivosYCarpetas = new ArrayList<>();
        this.nodos = new ArrayList<>();
        this.nombre = nombre;
        this.archivo = archivo;
    }

    public List<DefaultMutableTreeNode> getNodos() {
        return nodos;
    }

    public void setNodos(List<DefaultMutableTreeNode> nodos) {
        this.nodos = nodos;
    }

    public List<Nodo> getArchivosYCarpetas() {
        return archivosYCarpetas;
    }

    public void setArchivosYCarpetas(List<Nodo> archivosYCarpetas) {
        this.archivosYCarpetas = archivosYCarpetas;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public boolean isArchivo() {
        return archivo;
    }

    public void setArchivo(boolean archivo) {
        this.archivo = archivo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String imprimirEstructura(TreeNode nodo, String carpeta) {
        System.out.println( nodo.toString());
            Nodo nodoHijo = ((Nodo)((DefaultMutableTreeNode) nodo).getUserObject());
        if (nodo.getChildCount() >= 0) {
            
            String regresar = ("<" + carpeta + " nombre=\"" + nodoHijo.getNombre() + "\">");
                for (Enumeration e = nodo.children();
                        e.hasMoreElements(); ) {
                    if (nodoHijo.isArchivo()) {
                        return ("<ARCHIVO nombre=\"" + nodoHijo.getNombre() + "\" ubicacion=\"" + nodoHijo.getUbicacion() + "\"/>");
                    } else {
                        TreeNode n = (TreeNode)e.nextElement();
                        regresar += imprimirEstructura(n, "CARPETA");
                        regresar += ("</"+ carpeta + ">");
                        return regresar;
                    }
                }
            } else {
                return ("<ARCHIVO nombre=\"" + nodoHijo.getNombre() + "\" ubicacion=\"" + nodoHijo.getUbicacion() + "\"/>");
            }return ("<ARCHIVO nombre=\"" + nodoHijo.getNombre() + "\" ubicacion=\"" + nodoHijo.getUbicacion() + "\"/>");
    }
    
    public String toString() {
        return nombre;
    }
}
