/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Insertar extends Consultas {
    private List<Columnas> columnas;
    private List<Valores> valores;

    public Insertar(List<Columnas> columnas, List<Valores> valores, String nombreConsulta, String ubicacionConsulta) {
        super(nombreConsulta, ubicacionConsulta);
        this.columnas = columnas;
        this.valores = valores;
    }

    public List<Columnas> getColumnas() {
        return columnas;
    }

    public void setColumnas(List<Columnas> columnas) {
        this.columnas = columnas;
    }

    public List<Valores> getValores() {
        return valores;
    }

    public void setValores(List<Valores> valores) {
        this.valores = valores;
    }
}
