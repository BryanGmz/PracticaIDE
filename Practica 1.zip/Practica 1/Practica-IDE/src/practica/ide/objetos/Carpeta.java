/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Carpeta{

    private String ubicacionCarpeta;
    private List<Nodo> archivosYCarpetas;
        
    public Carpeta(String nombreCarpeta) {
        
        this.archivosYCarpetas = new ArrayList<>();
    }

    public List<Nodo> getCarpetas() {
        return archivosYCarpetas;
    }

    public void setCarpetas(List<Nodo> archivosYCarpetas) {
        this.archivosYCarpetas = archivosYCarpetas;
    }
    
    public String getUbicacionCarpeta() {
        return ubicacionCarpeta;
    }

    public void setUbicacionCarpeta(String ubicacionCarpeta) {
        this.ubicacionCarpeta = ubicacionCarpeta;
    }
    
    public void agregarArchivosYCarpetas(Nodo nodo) {
        this.archivosYCarpetas.add(nodo);
    }
}
