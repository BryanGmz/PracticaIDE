/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

/**
 *
 * @author USUARIO
 */
public class Columnas {
    private String nombreColumna;

    public Columnas(String nombreColumna) {
        this.nombreColumna = nombreColumna;
    }

    public String getNombreColumna() {
        return nombreColumna;
    }

    public void setNombreColumna(String nombreColumna) {
        this.nombreColumna = nombreColumna;
    }
}
