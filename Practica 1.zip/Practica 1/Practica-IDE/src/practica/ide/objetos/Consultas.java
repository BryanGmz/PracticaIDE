/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

/**
 *
 * @author USUARIO
 */
public class Consultas {
    private String nombreConsulta;
    String ubicacionConsulta;

    public Consultas(String nombreConsulta, String ubicacionConsulta) {
        this.nombreConsulta = nombreConsulta;
        this.ubicacionConsulta = ubicacionConsulta;
    }

    public String getNombreConsulta() {
        return nombreConsulta;
    }

    public void setNombreConsulta(String nombreConsulta) {
        this.nombreConsulta = nombreConsulta;
    }

    public String getUbicacionConsulta() {
        return ubicacionConsulta;
    }

    public void setUbicacionConsulta(String ubicacionConsulta) {
        this.ubicacionConsulta = ubicacionConsulta;
    }
}
