/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

/**
 *
 * @author USUARIO
 */
public class Asignaciones {
    private String columna;
    private String valor;
    private int valorNumerico;
    private boolean cadena;

    public Asignaciones(String columna, String valor, boolean cadena) {
        this.columna = columna;
        this.valor = valor;
        this.cadena = cadena;
    }

    public Asignaciones(String columna, int valorNumerico, boolean cadena) {
        this.columna = columna;
        this.valorNumerico = valorNumerico;
        this.cadena = cadena;
    }

    public String getColumna() {
        return columna;
    }

    public void setColumna(String columna) {
        this.columna = columna;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public int getValorNumerico() {
        return valorNumerico;
    }

    public void setValorNumerico(int valorNumerico) {
        this.valorNumerico = valorNumerico;
    }

    public boolean isCadena() {
        return cadena;
    }

    public void setCadena(boolean cadena) {
        this.cadena = cadena;
    }
}
