/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

/**
 *
 * @author USUARIO
 */
public class Archivo {
    private String ubicacionArchivo;

    public Archivo(String nombreArchivo, String ubicacionArchivo) {
        
        this.ubicacionArchivo = ubicacionArchivo;
    }

    public String getUbicacionArchivo() {
        return ubicacionArchivo;
    }

    public void setUbicacionArchivo(String ubicacionArchivo) {
        this.ubicacionArchivo = ubicacionArchivo;
    }
}
