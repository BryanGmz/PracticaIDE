/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.awt.Component;
import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import practica.ide.GuardarArchivo;
import practica.ide.LeerArchivo;
import practica.ide.objetos.Actualizar;
import practica.ide.objetos.Filtros;
import practica.ide.objetos.Nodo;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Valores;

/**
 *
 * @author USUARIO
 */
public class ManejadorActualizar {
    private final ManejadorBuscarArchivo buscarArchivo = new ManejadorBuscarArchivo();
    private final LeerArchivo leerArchivo = new LeerArchivo();
    private final ManejadorCreadorObjetos creadorObjetos = new ManejadorCreadorObjetos();
    private final ManejadorColumnas manejadorColumnas = new ManejadorColumnas();
    private final ManejadorFiltraciones manejadorFiltraciones = new ManejadorFiltraciones();
    private final GuardarArchivo guardarArchivo = new GuardarArchivo();
    private final ManejadorImprimir manejadorImprimir = new ManejadorImprimir();
    
    public void consultaActualizar(Actualizar actualizar, JTree arbol, JTextArea txtAreaSQL, Component component){
        List<Objeto> listaObjetos;
        String [] separar  = actualizar.getUbicacionConsulta().split("\\.");
        String txtAnterior;
        Nodo nodo = buscarArchivo.buscarArchivo(arbol, txtAreaSQL, separar[separar.length - 1], actualizar.getUbicacionConsulta());
        if (nodo != null) {
            txtAnterior = txtAreaSQL.getText();
            txtAreaSQL.setText("");
            System.out.println("Entro");
            leerArchivo.leerArchivoCSV(txtAreaSQL, component, nodo.getUbicacion());
            if (txtAreaSQL.getText().isEmpty()) {
                txtAnterior += "\n\nError Sintactico";
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            } else {
                listaObjetos = creadorObjetos.constructorObjeto(txtAreaSQL.getText());
                realizarActuzalizar(listaObjetos, actualizar, txtAreaSQL, nodo.getUbicacion());
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            }
        } else {
            txtAreaSQL.setText(txtAreaSQL.getText() + "\n\n" + actualizar.getUbicacionConsulta() + " NO ENCONTRADO");
        }
    }
    
    public void realizarActuzalizar(List<Objeto> objetos, Actualizar actualizar, JTextArea textArea, String pathArchivo) {
        List<Objeto> list;
        String salida;
        if (actualizar.getFiltros().isEmpty()) {
            list = actualizarSinFiltros(objetos, actualizar);
        } else {
            list = actualizarConFiltraciones(objetos, actualizar);
        }
        salida = objetosEscribir(list);
        if (!list.isEmpty()) {
            try {
                guardarArchivo.guardar(salida, null, pathArchivo);
                System.out.println("Salida\n" + salida);
            } catch (IOException ex) {
                System.out.println(ex.toString());
            }
        }
        manejadorImprimir.imprimir(textArea, objetos, null);
        System.out.println("Salida \n" + salida + "\nFin Salida");
    }
    
    public List<Objeto> actualizarSinFiltros(List<Objeto> objetos, Actualizar actualizar) {
        JOptionPane.showMessageDialog(null, "Actualizado");
        return manejadorColumnas.columnasActualizar(objetos, actualizar.getAsignaciones(), objetos.get(0), 1);
    }
    
    public List<Objeto> actualizarConFiltraciones(List<Objeto> listaObjetos, Actualizar actualizar) {
        Filtros f;
        List<Filtros> fil = new ArrayList<>();
        if (actualizar.getFiltros().size() > 1) {
            for (int i = 0; i <  actualizar.getFiltros().size(); i++) {
                fil.add(actualizar.getFiltros().get(i));
            }
            f = new Filtros(fil.get(1).getTipo(), new ArrayList<>());
            f.setFs(fil);
            actualizar.setFilt(f);
        } else {
            f = new Filtros(1, new ArrayList<>());
            f.setFs(actualizar.getFiltros());
            actualizar.setFilt(f);
        }
        Objeto objetoIncial = listaObjetos.get(0);
        List<Objeto> filtrados = manejadorFiltraciones.filtraciones(actualizar.getFilt(), listaObjetos);
        if (filtrados.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Actualizado");
            return listaObjetos;
        } else {
            filtrados = manejadorColumnas.columnasActualizar(filtrados, actualizar.getAsignaciones(), objetoIncial, 0);   
            JOptionPane.showMessageDialog(null, "Actualizado");
            return filtrados;
        }
    }
    
    public String objetosEscribir(List<Objeto> objetos) {
        String salida = "";
        for (int i = 0; i < objetos.size(); i++) {
            for (int j = 0; j < objetos.get(i).getAtributos().size(); j++) {
                Valores valores = objetos.get(i).getAtributos().get(j);
                
                if (i == 0) {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        salida += valores.getValor() + "\n";
                    } else {
                        salida += valores.getValor() + ",";
                    }
                } else {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + "\n";
                        } else {
                            salida += valores.getValorNumerico() + "\n";
                        }
                    } else {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + ",";
                        } else {
                            salida += valores.getValorNumerico() + ",";
                        }
                    }
                    
                }
            }
        }
        return salida;
    }
}
