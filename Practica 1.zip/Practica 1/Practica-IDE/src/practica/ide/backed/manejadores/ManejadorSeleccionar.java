/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.JTree;
import practica.ide.LeerArchivo;
import practica.ide.objetos.Filtros;
import practica.ide.objetos.Nodo;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Seleccionar;

/**
 *
 * @author USUARIO
 */
public class ManejadorSeleccionar {
    private final ManejadorBuscarArchivo buscarArchivo = new ManejadorBuscarArchivo();
    private final LeerArchivo leerArchivo = new LeerArchivo();
    private final ManejadorCreadorObjetos creadorObjetos = new ManejadorCreadorObjetos();
    private final ManejadorFiltraciones manejadorFiltraciones = new ManejadorFiltraciones();
    private final ManejadorColumnas manejadorColumnas = new ManejadorColumnas();
    private final ManejadorImprimir manejadorImprimir = new ManejadorImprimir();
            
    public void consultaSeleccionar(Seleccionar seleccionar, JTree arbol, JTextArea txtAreaSQL, Component component){
        List<Objeto> listaObjetos;
        String [] separar  = seleccionar.getUbicacionConsulta().split("\\.");
        String txtAnterior;
        Nodo nodo = buscarArchivo.buscarArchivo(arbol, txtAreaSQL, separar[separar.length - 1], seleccionar.getUbicacionConsulta());
        if (nodo != null) {
            txtAnterior = txtAreaSQL.getText();
            txtAreaSQL.setText("");
            System.out.println("Entro");
            leerArchivo.leerArchivoCSV(txtAreaSQL, component, nodo.getUbicacion());
            if (txtAreaSQL.getText().isEmpty()) {
                txtAnterior += "\n\nError Sintactico";
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            } else {//
                listaObjetos = creadorObjetos.constructorObjeto(txtAreaSQL.getText());
                obtenerSelect(listaObjetos, seleccionar, txtAreaSQL);
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            }
        } else {
            txtAreaSQL.setText(txtAreaSQL.getText() + "\n\n" + seleccionar.getUbicacionConsulta() + " NO ENCONTRADO");
        }
    }
    
    public void obtenerSelect(List<Objeto> listaObjetos, Seleccionar seleccionar, JTextArea textArea){
        List<Objeto> listaFinalMostrar;
        if (seleccionar.getColumnas().isEmpty() && seleccionar.getFiltros().isEmpty()) {//Todos los objetos mostrar
            listaFinalMostrar = mostrarTodos(listaObjetos);
        } else if (seleccionar.getColumnas().isEmpty()){//Mostrar todos pero con filtraciones 
            listaFinalMostrar = mostrarSoloFiltros(listaObjetos, seleccionar);
        } else if (seleccionar.getFiltros().isEmpty()) {//Mostrar columnas seleccionadas sin filtraciones
            listaFinalMostrar = mostrarSoloColumnas(listaObjetos, seleccionar);
        } else {//Mostrar columnas seleccionados y con filtraciones
            listaFinalMostrar = mostrarColumnasYFiltraciones(listaObjetos, seleccionar);
        }
        manejadorImprimir.imprimir(textArea, listaFinalMostrar, listaObjetos.get(0));
    }
    
    public List<Objeto> mostrarTodos(List<Objeto> listaObjetos) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < listaObjetos.size(); i++) {
            objetos.add(listaObjetos.get(i));
        }
        return objetos;
    }
    
    public List<Objeto> mostrarSoloFiltros(List<Objeto> listaObjetos, Seleccionar seleccionar) {
        Filtros f;
        List<Filtros> fil = new ArrayList<>();
        if (seleccionar.getFiltros().size() > 1) {
            for (int i = 0; i <  seleccionar.getFiltros().size(); i++) {
                fil.add(seleccionar.getFiltros().get(i));
            }
            f = new Filtros(fil.get(1).getTipo(), new ArrayList<>());
            f.setFs(fil);
            seleccionar.setFilt(f);
        } else {
            f = new Filtros(1, new ArrayList<>());
            f.setFs(seleccionar.getFiltros());
            seleccionar.setFilt(f);
        }
        List<Objeto> filtrados = manejadorFiltraciones.filtraciones(seleccionar.getFilt(), listaObjetos);
        return filtrados;
    }
    
    public List<Objeto> mostrarSoloColumnas(List<Objeto> listaObjetos, Seleccionar seleccionar) {
        List<Objeto> filtrados = manejadorColumnas.columnas(listaObjetos, seleccionar.getColumnas());
        return filtrados;
    }
    
    public List<Objeto> mostrarColumnasYFiltraciones(List<Objeto> listaObjetos, Seleccionar seleccionar) {
        Filtros f;
        List<Filtros> fil = new ArrayList<>();
        if (seleccionar.getFiltros().size() > 1) {
            for (int i = 0; i <  seleccionar.getFiltros().size(); i++) {
                fil.add(seleccionar.getFiltros().get(i));
            }
            f = new Filtros(fil.get(1).getTipo(), new ArrayList<>());
            f.setFs(fil);
            seleccionar.setFilt(f);
        } else {
            f = new Filtros(1, new ArrayList<>());
            f.setFs(seleccionar.getFiltros());
            seleccionar.setFilt(f);
        }
        Objeto objetoIncial = listaObjetos.get(0);
        List<Objeto> filtrados = manejadorFiltraciones.filtraciones(seleccionar.getFilt(), listaObjetos);
        filtrados = manejadorColumnas.columnasF(filtrados, seleccionar.getColumnas(), objetoIncial);     
        comparar(filtrados, listaObjetos);
        return listaObjetos;
    }
    
    private void comparar(List<Objeto> list, List<Objeto> objetos) {
        for (int i = 0; i < list.size(); i++) {
            if (objetos.contains(list.get(i))) {
                System.out.println("Contiene");
            } else {
                System.out.println("No contiene");
            }
        }
    }
    
}
