/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.awt.Component;
import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import practica.ide.GuardarArchivo;
import practica.ide.LeerArchivo;
import practica.ide.objetos.Insertar;
import practica.ide.objetos.Nodo;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Valores;

/**
 *
 * @author USUARIO
 */
public class ManejadorInsertar {
    private final ManejadorBuscarArchivo buscarArchivo = new ManejadorBuscarArchivo();
    private final LeerArchivo leerArchivo = new LeerArchivo();
    private final GuardarArchivo guardarArchivo = new GuardarArchivo();
    private final ManejadorCreadorObjetos creadorObjetos = new ManejadorCreadorObjetos();
    private final ManejadorColumnas manejadorColumnas = new ManejadorColumnas();
    private final ManejadorImprimir manejadorImprimir = new ManejadorImprimir();
    
    public void consultaInsertar(Insertar insertar, JTree arbol, JTextArea txtAreaSQL, Component component){
        List<Objeto> listaObjetos;
        String [] separar  = insertar.getUbicacionConsulta().split("\\.");
        String txtAnterior;
        Nodo nodo = buscarArchivo.buscarArchivo(arbol, txtAreaSQL, separar[separar.length - 1], insertar.getUbicacionConsulta());
        if (nodo != null) {
            txtAnterior = txtAreaSQL.getText();
            txtAreaSQL.setText("");
            System.out.println("Entro");
            leerArchivo.leerArchivoCSV(txtAreaSQL, component, nodo.getUbicacion());
            if (txtAreaSQL.getText().isEmpty()) {
                txtAnterior += "\n\nError Sintactico";
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            } else {
                listaObjetos = creadorObjetos.constructorObjeto(txtAreaSQL.getText());
                realizarInsertar(listaObjetos, insertar, txtAreaSQL, nodo.getUbicacion());
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            }
        } else {
            txtAreaSQL.setText(txtAreaSQL.getText() + "\n\n" + insertar.getUbicacionConsulta() + " NO ENCONTRADO");
        }
    }
    
    public void realizarInsertar(List<Objeto> objetos, Insertar insertar, JTextArea textArea, String pathArchivo){
        List<Objeto> list;
        String salida;
        if (insertar.getColumnas().isEmpty()) {//Consuta sin columnas a insertar
            list = insertarSinColumnas(objetos, insertar);
        } else {
            list = insertarConColumnas(objetos, insertar);
        }
        salida = objetosEscribir(list);
        if (!list.isEmpty()) {
            try {
                guardarArchivo.guardar(salida, null, pathArchivo);
                System.out.println("Salida\n" + salida);
                JOptionPane.showMessageDialog(null, "Insertado");
            } catch (HeadlessException | IOException ex) {
                System.out.println(ex.toString());
            }
        }
        manejadorImprimir.imprimir(textArea, objetos, null);
    }
    
    public List<Objeto> insertarConColumnas(List<Objeto> objetos, Insertar insertar) {
        return manejadorColumnas.columnasValoresInsertar(objetos, insertar.getColumnas(), insertar.getValores(), objetos.get(0));
    }
    
    public List<Objeto> insertarSinColumnas(List<Objeto> objetos, Insertar insertar) {
        return manejadorColumnas.columnasValoresInsertar(objetos, new ArrayList<>(), insertar.getValores(), objetos.get(0));
    }
    
    public String objetosEscribir(List<Objeto> objetos) {
        String salida = "";
        for (int i = 0; i < objetos.size(); i++) {
            for (int j = 0; j < objetos.get(i).getAtributos().size(); j++) {
                Valores valores = objetos.get(i).getAtributos().get(j);
                
                if (i == 0) {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        salida += valores.getValor() + "\n";
                    } else {
                        salida += valores.getValor() + ",";
                    }
                } else {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + "\n";
                        } else {
                            salida += valores.getValorNumerico() + "\n";
                        }
                    } else {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + ",";
                        } else {
                            salida += valores.getValorNumerico() + ",";
                        }
                    }
                    
                }
            }
        }
        return salida;
    }
}
