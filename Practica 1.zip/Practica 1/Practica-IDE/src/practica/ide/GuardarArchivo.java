/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide;

import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.tree.TreeNode;
import practica.ide.backed.analizador.Lexico;
import practica.ide.backed.analizador.Sintax;

/**
 *
 * @author USUARIO
 */
public class GuardarArchivo {
    
    public String guardar(String textoSalida, Component component, String pathProyecto) throws FileNotFoundException, IOException{
        String regresar = null;
        File chooser = new File(pathProyecto);
        try (FileOutputStream salida = new FileOutputStream(chooser)) {
            byte[] byteTxt = textoSalida.getBytes();
            salida.write(byteTxt);
            regresar = "Guardado";
        }
        return regresar;
    }
    
    public String guardarProyecto(String textoSalida, Component component, String pathProyecto, File file) throws FileNotFoundException, IOException{
        String regresar = null;
        File chooser = file;
        try (FileOutputStream salida = new FileOutputStream(chooser)) {
            byte[] byteTxt = textoSalida.getBytes();
            salida.write(byteTxt);
            regresar = "Guardado";
        }
        return regresar;
    }
    
    
}
