/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.awt.Component;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.JTree;
import practica.ide.objetos.Actualizar;
import practica.ide.objetos.Consultas;
import practica.ide.objetos.Eliminar;
import practica.ide.objetos.Insertar;
import practica.ide.objetos.Seleccionar;

/**
 *
 * @author USUARIO
 */
public class ManejadorConsultas {
    private JTextArea areaTextoSQL;
    private JTextArea error;
    private final ManejadorActualizar manejadorActualizar = new ManejadorActualizar();
    private final ManejadorBuscarArchivo manejadorBuscarArchivo = new ManejadorBuscarArchivo();
    private final ManejadorEliminar manejadorEliminar = new ManejadorEliminar();
    private final ManejadorInsertar manejadorInsertar = new ManejadorInsertar();
    private final ManejadorSeleccionar manejadorSeleccionar = new ManejadorSeleccionar();
    
    public ManejadorConsultas(JTextArea areaTextoSQL, JTextArea error) {
        this.areaTextoSQL = areaTextoSQL;
        this.error = error;
    }

    public JTextArea getAreaTextoSQL() {
        return areaTextoSQL;
    }

    public void setAreaTextoSQL(JTextArea areaTextoSQL) {
        this.areaTextoSQL = areaTextoSQL;
    }
    
    public void creacionConsultas(List<Consultas> consultas, JTree arbol, Component component){
        System.out.println("Ds");
        for (int i = 0; i < consultas.size(); i++) {
            System.out.println("Nombre Consulta " + consultas.get(i).getNombreConsulta());
            switch (consultas.get(i).getNombreConsulta()) {
                case "Actualizar":
                    System.out.println("Actualizar");
                    manejadorActualizar.consultaActualizar((Actualizar) consultas.get(i), arbol, areaTextoSQL, component, error);
                    break;
                case "Eliminar":
                    System.out.println("Eliminar");
                    manejadorEliminar.consultaSeleccionar((Eliminar) consultas.get(i), arbol, areaTextoSQL, component, error);
                    break;
                case "Seleccionar":
                    System.out.println("Seleccionar");
                    manejadorSeleccionar.consultaSeleccionar((Seleccionar) consultas.get(i), arbol, areaTextoSQL, component, error);
                    break;
                case "Insertar":
                    System.out.println("Insertar");
                    manejadorInsertar.consultaInsertar((Insertar) consultas.get(i), arbol, areaTextoSQL, component, error);
                    break;
                default:
                    throw new AssertionError();
            }
        }
    }
}
