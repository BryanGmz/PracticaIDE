/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.util.ArrayList;
import java.util.List;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Valores;

/**
 *
 * @author USUARIO
 */
public class ManejadorCreadorObjetos {
    
    public List<Objeto> constructorObjeto(String entradaSintax){
        List<Objeto> objetos = new ArrayList<>();
        String [] entrada = entradaSintax.split("\n");
        for (String entrada1 : entrada) {
            List<Valores> lista = new ArrayList<>();
            Objeto objeto = new Objeto(lista);
            String partir [] = entrada1.split(",");
            for (String partir1 : partir) {
                try {
                    int valorNumerico = Integer.parseInt(partir1);
                    Valores atributo = new Valores(valorNumerico, false);
                    lista.add(atributo);
                } catch (NumberFormatException e) {
                    String comparacion = partir1.replace("\r", "");
                    Valores atributo = new Valores(comparacion, true);
                    lista.add(atributo);
                }
            }
            objetos.add(objeto);
        } return objetos;
    }
}
