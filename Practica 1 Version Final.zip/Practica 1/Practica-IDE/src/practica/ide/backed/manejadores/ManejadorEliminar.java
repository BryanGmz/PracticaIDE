/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.awt.Component;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.JTree;
import practica.ide.GuardarArchivo;
import practica.ide.LeerArchivo;
import practica.ide.objetos.Eliminar;
import practica.ide.objetos.Filtros;
import practica.ide.objetos.Nodo;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Valores;

/**
 *
 * @author USUARIO
 */
public class ManejadorEliminar {
    private final ManejadorBuscarArchivo buscarArchivo = new ManejadorBuscarArchivo();
    private final LeerArchivo leerArchivo = new LeerArchivo();
    private final ManejadorCreadorObjetos creadorObjetos = new ManejadorCreadorObjetos();
    private final ManejadorFiltraciones manejadorFiltraciones = new ManejadorFiltraciones();
    private final ManejadorImprimir manejadorImprimir = new ManejadorImprimir();
    private final GuardarArchivo guardarArchivo = new GuardarArchivo();
    
    public void consultaSeleccionar(Eliminar eliminar, JTree arbol, JTextArea txtAreaSQL, Component component, JTextArea error){
        List<Objeto> listaObjetos;
        String [] separar  = eliminar.getUbicacionConsulta().split("\\.");
        String txtAnterior;
        Nodo nodo = buscarArchivo.buscarArchivo(arbol, txtAreaSQL, separar[separar.length - 1], eliminar.getUbicacionConsulta());
        if (nodo != null) {
            txtAnterior = txtAreaSQL.getText();
            txtAreaSQL.setText("");
            System.out.println("Entro");
            leerArchivo.leerArchivoCSV(txtAreaSQL, component, nodo.getUbicacion(), error);
            if (txtAreaSQL.getText().isEmpty()) {
                txtAnterior += "\n\nError Sintactico";
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            } else {//
                listaObjetos = creadorObjetos.constructorObjeto(txtAreaSQL.getText());
                System.out.println("Lista " + objetosEscribir(listaObjetos));
                eliminar(listaObjetos, eliminar, txtAreaSQL, nodo.getUbicacion());
                txtAreaSQL.setText(txtAnterior + txtAreaSQL.getText());
            }
        } else {
            txtAreaSQL.setText(txtAreaSQL.getText() + "\n\n" + eliminar.getUbicacionConsulta() + " NO ENCONTRADO");
        }
    }
    
    public void eliminar(List<Objeto> listaObjetos, Eliminar eliminar, JTextArea textArea, String pathArchivo){
        List<Objeto> listaFinalEliminar;
        String salida;
        Objeto unicoObjet;
        if (eliminar.getFiltros().isEmpty()) {
            unicoObjet = listaObjetos.get(0);
            listaFinalEliminar = new ArrayList<>();
            listaFinalEliminar.add(unicoObjet);
        } else {
            unicoObjet = listaObjetos.get(0);
            listaFinalEliminar = eliminarConFiltros(listaObjetos, eliminar);
            listaFinalEliminar.add(0, unicoObjet);
        }
        salida = objetosEscribir(listaFinalEliminar);
         if (!listaFinalEliminar.isEmpty()) {
            try {
                guardarArchivo.guardar(salida, null, pathArchivo);
                System.out.println("Salida\n" + salida);
            } catch (Exception ex) {
                System.out.println(ex.toString());
            }
        }
        manejadorImprimir.imprimir(textArea, listaFinalEliminar, null);
        System.out.println("Salida \n" + salida + "\nFin Salida");
    }
    
    public List<Objeto> eliminarConFiltros(List<Objeto> listaObjetos, Eliminar seleccionar) {
        Filtros f;
        List<Filtros> fil = new ArrayList<>();
        if (seleccionar.getFiltros().size() > 1) {
            for (int i = 0; i <  seleccionar.getFiltros().size(); i++) {
                fil.add(seleccionar.getFiltros().get(i));
            }
            f = new Filtros(fil.get(1).getTipo(), new ArrayList<>());
            f.setFs(fil);
            seleccionar.setFilt(f);
        } else {
            f = new Filtros(1, new ArrayList<>());
            f.setFs(seleccionar.getFiltros());
            seleccionar.setFilt(f);
        }
        List<Objeto> filtrados = manejadorFiltraciones.filtracionesEliminar(seleccionar.getFilt(), listaObjetos);
        return filtrados;
    }
    
    public String objetosEscribir(List<Objeto> objetos) {
        String salida = "";
        for (int i = 0; i < objetos.size(); i++) {
            for (int j = 0; j < objetos.get(i).getAtributos().size(); j++) {
                Valores valores = objetos.get(i).getAtributos().get(j);
                if (i == 0) {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        salida += valores.getValor() + "\n";
                    } else {
                        salida += valores.getValor() + ",";
                    }
                } else {
                    if (j == objetos.get(i).getAtributos().size()-1) {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + "\n";
                        } else {
                            salida += valores.getValorNumerico() + "\n";
                        }
                    } else {
                        if (valores.getValor() != null) {
                            salida += valores.getValor() + ",";
                        } else {
                            salida += valores.getValorNumerico() + ",";
                        }
                    }
                    
                }
            }
        }
        return salida;
    }
}
