/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.util.Enumeration;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import practica.ide.objetos.Nodo;

/**
 *
 * @author USUARIO
 */
public class ManejadorBuscarArchivo {
    
    public Nodo buscarArchivo(JTree arbol, JTextArea txtAreaSQL, String pathArchivo, String pathCompleto){
        TreeNode raiz = (TreeNode) arbol.getModel().getRoot();
        TreePath path = buscar((DefaultMutableTreeNode) raiz, pathArchivo);
        String ubicacion = "";
        System.out.println("JO");
        if (path != null) {
            arbol.setSelectionPath(path);
            for (int i = 0; i < path.getPathCount(); i++) {
                if (i == 0) {
                    ubicacion = path.getPathComponent(i).toString();
                } else {
                    ubicacion += "." + path.getPathComponent(i).toString();
                }
            }
            System.out.println("Ubicacion " + ubicacion);
            if (!"".equals(ubicacion)) {
                TreeSelectionModel tsm = arbol.getSelectionModel();
                if (tsm.getSelectionCount() > 0) {
                    DefaultMutableTreeNode nodoSeleccionado = (DefaultMutableTreeNode) arbol.getSelectionPath().getLastPathComponent();
                    Nodo nodo = ((Nodo) nodoSeleccionado.getUserObject());
                    System.out.println("Nombre: "+ nodo.getNombre() + " Path: " + nodo.getUbicacion());
                    if ((comprobarPath(pathCompleto, ubicacion))) {
                        System.out.println("Hola P");
                        return nodo;
                    } else {
                        return null;
                    }
                }
            } else {
                System.out.println("No encontrado");
                return null;
            }   
        } else {
            System.out.println("No encontrado");
            return null;
        }
        return null;
    }
    
    public TreePath buscar(DefaultMutableTreeNode modelo, String buscando) { 
        @SuppressWarnings("unchecked") Enumeration e = modelo.depthFirstEnumeration();
        while (e.hasMoreElements()) { 
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) e.nextElement();
            if (node.toString().equalsIgnoreCase(buscando)) { 
                return new TreePath(node.getPath()); 
            } 
        } return null; 
    }
    
    public boolean comprobarPath(String pathArchivo, String pathGenerado) {
        return pathArchivo.equalsIgnoreCase(pathGenerado);
    } 
}
