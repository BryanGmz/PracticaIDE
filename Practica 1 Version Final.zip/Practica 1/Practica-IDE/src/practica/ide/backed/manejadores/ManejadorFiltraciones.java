/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import practica.ide.objetos.Condicion;
import practica.ide.objetos.Filtros;
import practica.ide.objetos.Objeto;

/**
 *
 * @author USUARIO
 */
public class ManejadorFiltraciones {
    
    public List<Objeto> filtraciones(Filtros filtros, List<Objeto> objetosArchivo){
        List<Objeto> objetos = new ArrayList<>();
        if (filtros.getTipo() == 1) {
            //Solo una condicion
            objetos = filtrar(objetosArchivo, filtros.getFs().get(0), indiceColumna(objetosArchivo.get(0), filtros.getFs().get(0).getCondiciones().get(0).getColumna()));
        } else {
            if (filtros.getTipo() == 2) {
                objetos = filtroAND(objetosArchivo, filtros);
            } else if (filtros.getTipo() == 3) {
                objetos = filtroOR(objetosArchivo, filtros);
            }
        }
        return objetos;
    }
    
    public List<Objeto> filtracionesEliminar(Filtros filtros, List<Objeto> objetosArchivo){
        List<Objeto> objetos = new ArrayList<>();
        if (filtros.getTipo() == 1) {
            //Solo una condicion
            objetos = filtrarActualizarEliminar(objetosArchivo, filtros.getFs().get(0), indiceColumna(objetosArchivo.get(0), filtros.getFs().get(0).getCondiciones().get(0).getColumna()));
        } else {
            if (filtros.getTipo() == 2) {
                objetos = filtroANDEliminar(objetosArchivo, filtros);
            } else if (filtros.getTipo() == 3) {
                objetos = filtroOREliminar(objetosArchivo, filtros);
            }
        }
        return objetos;
    }
    
    public List<Objeto> filtroAND(List<Objeto> lista, Filtros filtros) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            List<Objeto> temp;
            int comprobar = 0;
            for (int j = 0; j < filtros.getFs().size(); j++) {
                temp = filtrar(lista, filtros.getFs().get(j), indiceColumna(lista.get(0), filtros.getFs().get(j).getCondiciones().get(0).getColumna()));
                if (temp.contains(lista.get(i))) {
                    comprobar++;
                } 
                if (j == (filtros.getFs().size()-1)) {
                    if (comprobar == filtros.getFs().size()) {
                        objetos.add(lista.get(i));
                    }
                }
            }
        }
        return objetos;
    }
    
    public List<Objeto> filtroOR(List<Objeto> lista, Filtros filtros) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            List<Objeto> temp;
            int comprobar = 0;
            for (int j = 0; j < filtros.getFs().size(); j++) {
                temp = filtrar(lista, filtros.getFs().get(j), indiceColumna(lista.get(0), filtros.getFs().get(j).getCondiciones().get(0).getColumna()));
                if (temp.contains(lista.get(i))) {
                    comprobar++;
                } 
                if (j == (filtros.getFs().size()-1)) {
                    if (comprobar >= 1) {
                        objetos.add(lista.get(i));
                    }
                }
            }
        }
        return objetos;
    }
    public List<Objeto> filtroANDEliminar(List<Objeto> lista, Filtros filtros) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            List<Objeto> temp;
            int comprobar = 0;
            for (int j = 0; j < filtros.getFs().size(); j++) {
                temp = filtrarActualizarEliminar(lista, filtros.getFs().get(j), indiceColumna(lista.get(0), filtros.getFs().get(j).getCondiciones().get(0).getColumna()));
                if (temp.contains(lista.get(i))) {
                    comprobar++;
                } 
                if (j == (filtros.getFs().size()-1)) {
                    if (comprobar == filtros.getFs().size()) {
                        objetos.add(lista.get(i));
                    }
                }
            }
        }
        return objetos;
    }
    
    public List<Objeto> filtroOREliminar(List<Objeto> lista, Filtros filtros) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            List<Objeto> temp;
            int comprobar = 0;
            for (int j = 0; j < filtros.getFs().size(); j++) {
                temp = filtrarActualizarEliminar(lista, filtros.getFs().get(j), indiceColumna(lista.get(0), filtros.getFs().get(j).getCondiciones().get(0).getColumna()));
                if (temp.contains(lista.get(i))) {
                    comprobar++;
                } 
                if (j == (filtros.getFs().size()-1)) {
                    if (comprobar >= 1) {
                        objetos.add(lista.get(i));
                    }
                }
            }
        }
        return objetos;
    }
    
        public List<Objeto> filtrar(List<Objeto> lista, Filtros condicions, int indice) {
        List<Objeto> objetos = new ArrayList<>();
            try {
            for (int i = 1; i < lista.size(); i++) {
                if (condicions.getCondiciones().get(0).isCadena()) {
                    switch (condicions.getCondiciones().get(0).getTipoCondicion()) {
                        case 1:
                            System.out.println("Val " + condicions.getCondiciones().get(0).getValor() + " " + condicions.getCondiciones().get(0).isCadena());
                            if (lista.get(i).getAtributos().get(indice).getValor().equalsIgnoreCase(condicions.getCondiciones().get(0).getValor())) {
                                objetos.add(lista.get(i));
                            } 
                            break;
                        case 2:
                            if (condicions.getCondiciones().get(0).getValor().length() > lista.get(i).getAtributos().get(indice).getValor().length()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 3:
                            if (condicions.getCondiciones().get(0).getValor().length() < lista.get(i).getAtributos().get(indice).getValor().length()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 4:
                            if (condicions.getCondiciones().get(0).getValor().length() >= lista.get(i).getAtributos().get(indice).getValor().length()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 5:
                            if (condicions.getCondiciones().get(0).getValor().length() <= lista.get(i).getAtributos().get(indice).getValor().length()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 6:
                            if (condicions.getCondiciones().get(0).getValor().length() != lista.get(i).getAtributos().get(indice).getValor().length()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        default:
                            System.out.println("Ninguno");
                    }
                } else {
                    switch (condicions.getCondiciones().get(0).getTipoCondicion()) {
                        case 1:
                            if (lista.get(i).getAtributos().get(indice).getValorNumerico() == condicions.getCondiciones().get(0).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            } 
                            break;
                        case 2:
                            if (condicions.getCondiciones().get(0).getValorNumerico() > lista.get(i).getAtributos().get(indice).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 3:
                            if (condicions.getCondiciones().get(0).getValorNumerico() < lista.get(i).getAtributos().get(indice).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 4:
                            if (condicions.getCondiciones().get(0).getValorNumerico() >= lista.get(i).getAtributos().get(indice).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 5:
                            if (condicions.getCondiciones().get(0).getValorNumerico() <= lista.get(i).getAtributos().get(indice).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 6:
                            if (condicions.getCondiciones().get(0).getValorNumerico() != lista.get(i).getAtributos().get(indice).getValorNumerico()) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        default:
                            System.out.println("Ninguno");
                    }
                    }
                }
                return objetos;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error no se pueden comparar Cadenas con Enteros", "ERROR", JOptionPane.ERROR_MESSAGE);
            return objetos;
        }
    }
    
        
    public List<Objeto> filtrarActualizarEliminar(List<Objeto> lista, Filtros condicions, int indice) {
        List<Objeto> objetos = new ArrayList<>();
            
            for (int i = 1; i < lista.size(); i++) {
                try {
                    lista.get(i).setIndice(i);
                    System.out.println("Val " + condicions.getCondiciones().get(0).getValor() + " " + condicions.getCondiciones().get(0).isCadena());
                    System.out.println("Val " + condicions.getCondiciones().get(0).getValorNumerico()+ " " + condicions.getCondiciones().get(0).getColumna());
                    System.out.println("Val " + indice + " " + i);

                if (condicions.getCondiciones().get(0).isCadena()) {
                    switch (condicions.getCondiciones().get(0).getTipoCondicion()) {
                        case 1:
                            System.out.println("Val " + condicions.getCondiciones().get(0).getValor() + " " + condicions.getCondiciones().get(0).isCadena());
                            if (!(lista.get(i).getAtributos().get(indice).getValor().
                                    equalsIgnoreCase(condicions.getCondiciones().get(0).getValor()))) {
                                objetos.add(lista.get(i));
                            } 
                            break;
                        case 2:
                            if (!(condicions.getCondiciones().get(0).getValor().length() > lista.get(i).getAtributos().get(indice).getValor().length())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 3:
                            if (!(condicions.getCondiciones().get(0).getValor().length() < lista.get(i).getAtributos().get(indice).getValor().length())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 4:
                            if (!(condicions.getCondiciones().get(0).getValor().length() >= lista.get(i).getAtributos().get(indice).getValor().length())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 5:
                            if (!(condicions.getCondiciones().get(0).getValor().length() <= lista.get(i).getAtributos().get(indice).getValor().length())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 6:
                            if (!(condicions.getCondiciones().get(0).getValor().length() != lista.get(i).getAtributos().get(indice).getValor().length())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        default:
                            System.out.println("Ninguno");
                    }
                } else {
                    switch (condicions.getCondiciones().get(0).getTipoCondicion()) {
                        case 1:
                            if (!(lista.get(i).getAtributos().get(indice).getValorNumerico() == condicions.getCondiciones().get(0).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            } 
                            break;
                        case 2:
                            if (!(condicions.getCondiciones().get(0).getValorNumerico() > lista.get(i).getAtributos().get(indice).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 3:
                            if (!(condicions.getCondiciones().get(0).getValorNumerico() < lista.get(i).getAtributos().get(indice).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 4:
                            if (!(condicions.getCondiciones().get(0).getValorNumerico() >= lista.get(i).getAtributos().get(indice).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 5:
                            if (!(condicions.getCondiciones().get(0).getValorNumerico() <= lista.get(i).getAtributos().get(indice).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        case 6:
                            if (!(condicions.getCondiciones().get(0).getValorNumerico() != lista.get(i).getAtributos().get(indice).getValorNumerico())) {
                                objetos.add(lista.get(i));
                            }
                            break;
                        default:
                            System.out.println("Ninguno");
                    }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error no se pueden comparar Cadenas con Enteros o El objeto no contiene esa columna", "ERROR", JOptionPane.ERROR_MESSAGE);
                    objetos.add(lista.get(i));
                }
                }
                return objetos;
        
    }
        
    public int indiceColumna(Objeto objeto, String columna) {
        for (int i = 0; i < objeto.getAtributos().size(); i++) {
            String comparacion = objeto.getAtributos().get(i).getValor().replace("\r", "");
            comparacion = comparacion.replace("\n", "");
            comparacion = comparacion.replace("\t", "");
            if (comparacion.equalsIgnoreCase(columna)) {
                return i;
            } 
        }
        return -1;
    }
}
