/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.util.List;
import javax.swing.JTextArea;
import practica.ide.objetos.Objeto;

/**
 *
 * @author USUARIO
 */
public class ManejadorImprimir {
    
    public void imprimir(JTextArea textArea, List<Objeto> objetos, Objeto columna){
        String salida = "\n\n\n";
        if (columna != null) {
            for (int i = 0; i < columna.getAtributos().size(); i++) {
                salida += columna.getAtributos().get(i).getValor() + "\t";
            }
        }
        salida += "\n";
        for (int i = 0; i < objetos.size(); i++) {
            for (int j = 0; j < objetos.get(i).getAtributos().size(); j++) {
                if (objetos.get(i).getAtributos().get(j).getValor() != null) {
                    salida += objetos.get(i).getAtributos().get(j).getValor() + "\t";
                } else {
                    salida += objetos.get(i).getAtributos().get(j).getValorNumerico()+ "\t";
                }
            }
            salida += "\n";
        }
        textArea.setText(textArea.getText() + salida);
    }
}
