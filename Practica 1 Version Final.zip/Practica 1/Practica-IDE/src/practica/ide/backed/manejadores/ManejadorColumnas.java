/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.backed.manejadores;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import practica.ide.objetos.Asignaciones;
import practica.ide.objetos.Columnas;
import practica.ide.objetos.Objeto;
import practica.ide.objetos.Valores;

/**
 *
 * @author USUARIO
 */
public class ManejadorColumnas {
    
    public int indiceColumna(Objeto objeto, String columna) {
        for (int i = 0; i < objeto.getAtributos().size(); i++) {
            String comparacion = objeto.getAtributos().get(i).getValor().replace("\r", "");
            comparacion = comparacion.replace("\n", "");
            comparacion = comparacion.replace("\t", "");
            if (columna.equalsIgnoreCase(comparacion)) {
                return i;
            } 
        }
        return -1;
    }
    
    public List<Objeto> columnas(List<Objeto> lista, List<Columnas> columnas) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            Objeto temp;
            List<Valores> list = new ArrayList<>();
            for (int j = 0; j < columnas.size(); j++) {
                if (((lista.get(i).getAtributos().size()-1) 
                        >= indiceColumna(lista.get(0), columnas.get(j).getNombreColumna())) && (indiceColumna(lista.get(0), columnas.get(j).getNombreColumna()) >= 0)) {
                    list.add(lista.get(i).getAtributos().get(indiceColumna(lista.get(0), columnas.get(j).getNombreColumna())));
                }
            }
            temp = new Objeto(list);
            objetos.add(temp);
        }
        return objetos;
    }
    
    public List<Objeto> columnasActualizar(List<Objeto> lista, List<Asignaciones> asignaciones, Objeto objetoInicial, int objetNull) {
        List<Objeto> list = lista;
        List<Integer> listaIndices = ordenarIndicesActualizar(asignaciones, objetoInicial);
        Collections.sort(listaIndices);
        if (objetNull == 0) {
            list.add(0, objetoInicial);
        }
        for (int q = objetNull; q < lista.size(); q++) {
            for (int i = 0; i < objetoInicial.getAtributos().size(); i++) {
                for (int j = 0; j < listaIndices.size(); j++) {
                    System.out.println("Lista " + listaIndices.size());
                    System.out.println("Lista " + i);
                    int indice = listaIndices.get(j);
                    System.out.println("Lista Indice: " + indice);
                    if (indice == i) {
                        if (asignaciones.get(indice).getValor() != null) {
                            lista.get(q).getAtributos().get(i).setValor(asignaciones.get(indice).getValor());
                        } else {
                            lista.get(q).getAtributos().get(i).setValorNumerico(asignaciones.get(indice).getValorNumerico());
                        }
                    }
                }
                
            }
        }
        return list;
    }
    
    public List<Objeto> columnasValoresInsertar(List<Objeto> lista, List<Columnas> columnas, List<Valores> valores, Objeto objetoInicial) {
        List<Objeto> list = lista;
        Objeto objeto;
        if (columnas.isEmpty()) {
            objeto = new Objeto(valores);
        } else {
            List<Integer> listaIndices = ordenarIndices(columnas, objetoInicial);
            Collections.sort(listaIndices);
            List<Valores> nuevos = new ArrayList<>();
            int contador = 0;
            boolean bandera;
            for (int i = 0; i < objetoInicial.getAtributos().size(); i++) {
                bandera = false;
                for (int j = 0; j < listaIndices.size(); j++) {
                    int indice = listaIndices.get(j);
                    if (indice == i) {
                        nuevos.add(valores.get(contador));
                        contador++;
                        bandera = true;
                    }
                }
                if (!bandera) {
                    nuevos.add(new Valores(" ", true));
                }
            }
            objeto = new Objeto(nuevos);
        }
        list.add(objeto);
        return list;
    }
    
    private List<Integer> ordenarIndices(List<Columnas> columnas, Objeto objetoInicial) {
        List<Integer> listaIndices = new ArrayList<>();
        for (int i = 0; i < columnas.size(); i++) {
            int valor =  indiceColumna(objetoInicial, columnas.get(i).getNombreColumna());
            if (valor >= 0) {
                listaIndices.add(valor);
            }
        }
        Collections.sort(listaIndices);
        return listaIndices;
    }
    
    private List<Integer> ordenarIndicesActualizar(List<Asignaciones> asignaciones, Objeto objetoInicial) {
        List<Integer> listaIndices = new ArrayList<>();
        for (int i = 0; i < asignaciones.size(); i++) {
            int valor =  indiceColumna(objetoInicial, asignaciones.get(i).getColumna());
            if (valor >= 0) {
                listaIndices.add(valor);
            }
        }
        Collections.sort(listaIndices);
        return listaIndices;
    }
    
    public List<Objeto> columnasF(List<Objeto> lista, List<Columnas> columnas, Objeto inObjeto) {
        List<Objeto> objetos = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            Objeto temp;
            List<Valores> list = new ArrayList<>();
            for (int j = 0; j < columnas.size(); j++) {
                if (((lista.get(i).getAtributos().size()-1) >= indiceColumna(inObjeto, columnas.get(j).getNombreColumna())) && (indiceColumna(inObjeto, columnas.get(j).getNombreColumna()) >= 0)) {
                    list.add(lista.get(i).getAtributos().get(indiceColumna(inObjeto, columnas.get(j).getNombreColumna())));
                }
            }
            temp = new Objeto(list);
            objetos.add(temp);
        }
        return objetos;
    }
}
