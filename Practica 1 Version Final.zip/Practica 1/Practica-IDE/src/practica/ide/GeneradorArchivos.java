/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
/**
 *
 * @author Bryan
 */
public class GeneradorArchivos {
    
    public void GeneradorArchivos() throws Exception {
        String ruta1exicoProyecto = "src/practica/ide/backed/analizador/Lexico.flex";
        String[] rutaSintacticoProyecto = {"-parser", "Sintax", "src/practica/ide/backed/analizador/Sintax.cup"};
        generar(ruta1exicoProyecto, rutaSintacticoProyecto, "src/practica/ide/backed/analizador/sym.java", "sym.java", "src/practica/ide/backed/analizador/Sintax.java", "Sintax.java");
        
        String ruta1exicoCSV = "src/practica/ide/backed/analizador/CSV/LexicoCSV.flex";
        String[] rutaSintacticoCSV = {"-parser", "SintaxCSV", "src/practica/ide/backed/analizador/CSV/SintaxCSV.cup"};
        generar(ruta1exicoCSV, rutaSintacticoCSV, "src/practica/ide/backed/analizador/CSV/sym.java", "sym.java", "src/practica/ide/backed/analizador/CSV/SintaxCSV.java", "SintaxCSV.java");
        
        String ruta1exicoSQL = "src/practica/ide/backed/analizador/SQL/LexicoSQL.flex";
        String[] rutaSintacticoSQL = {"-parser", "SintaxSQL", "src/practica/ide/backed/analizador/SQL/SintaxSQL.cup"};
        generar(ruta1exicoSQL, rutaSintacticoSQL, "src/practica/ide/backed/analizador/SQL/sym.java", "sym.java", "src/practica/ide/backed/analizador/SQL/SintaxSQL.java", "SintaxSQL.java");
        
    }
    
    public void generar(String ruta1, String[] rutaS, String rutaSymTXT, String nombreSym, String rutaSint, String nombreSin) throws IOException, Exception{
        File archivo;
        archivo = new File(ruta1);
        jflex.Main.generate(archivo);
        java_cup.Main.main(rutaS);
        Path rutaSym = Paths.get(rutaSymTXT);
        System.out.println(rutaSym);
        if (Files.exists(rutaSym)) {
            Files.delete(rutaSym);
            System.out.println("Hola");
        }
//        File archivoRenombrar = new File("./sym.java");
//        File archivoRenombrado = new File("./"+ nombreSym);
//        if (archivoRenombrar.renameTo(archivoRenombrado)) {
//            System.out.println("Renombrado");
//        }
        Files.move(
                Paths.get(nombreSym), 
                Paths.get(rutaSymTXT)
        );
        Path rutaSin = Paths.get(rutaSint);
        if (Files.exists(rutaSin)) {
            Files.delete(rutaSin);
        }
        Files.move(
                Paths.get(nombreSin), 
                Paths.get(rutaSint)
        );
    }
}
