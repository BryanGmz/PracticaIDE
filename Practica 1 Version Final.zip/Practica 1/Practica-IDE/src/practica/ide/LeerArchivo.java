/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide;

import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.filechooser.FileNameExtensionFilter;
import practica.ide.backed.analizador.Lexico;
import practica.ide.backed.analizador.CSV.LexicoCSV;
import practica.ide.backed.analizador.Sintax;
import practica.ide.backed.analizador.CSV.SintaxCSV;

/**
 *
 * @author USUARIO
 */
public class LeerArchivo {
    
    public String leer(JTree arbol, FileNameExtensionFilter extensionFilter, Component component, JTextArea error){
        String path = "";
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(extensionFilter);
        int opcion = chooser.showOpenDialog(component);
        if (opcion == JFileChooser.APPROVE_OPTION) {
            String docIde = "";
            File archivo = chooser.getSelectedFile();
            path = archivo.getAbsolutePath();
            FileInputStream entrada;
            try {
                entrada = new FileInputStream(archivo);
                int e;
                while ((e=entrada.read()) != -1) {
                    char caracter = (char) e;
                    docIde += caracter;
                }
                entrada.close();
            } catch (IOException e) {
                e.toString();
            }
            
            Lexico lexico = new Lexico(new StringReader(docIde));
            try {
                Sintax s = new Sintax(lexico, arbol, error);
                s.parse();
            } catch (Exception ex) {
                ex.toString();
            }
        }
        return path;
    }
    
    public String leerArchivo(JTree arbol, FileNameExtensionFilter extensionFilter, Component component, File file, JTextArea error){
        String docIde = "";
        File archivo = file;
        String path = archivo.getAbsolutePath();
        FileInputStream entrada;
        try {
            entrada = new FileInputStream(archivo);
            int e;
            while ((e=entrada.read()) != -1) {
                char caracter = (char) e;
                docIde += caracter;
            }
            entrada.close();
        } catch (IOException e) {
            e.toString();
        }
          
            Lexico lexico = new Lexico(new StringReader(docIde));
            try {
                Sintax s = new Sintax(lexico, arbol, error);
                s.parse();
            } catch (Exception ex) {
                ex.toString();
            }
        return path;
    }
    
    public String leerArchivoCSV(JTextArea areaTxt, Component component, String pathCSV, JTextArea error){
        String docIde = "";
        File archivo = new File(pathCSV);
        String path = archivo.getAbsolutePath();
        FileInputStream entrada;
        try {
            entrada = new FileInputStream(archivo);
            int e;
            while ((e=entrada.read()) != -1) {
                char caracter = (char) e;
                docIde += caracter;
            }
            entrada.close();
        } catch (IOException e) {
            e.toString();
        }
        System.out.println("Doc " + docIde);  
        LexicoCSV lexico = new LexicoCSV(new StringReader(docIde));
        try {
            SintaxCSV s = new SintaxCSV(lexico, areaTxt, docIde, error);
            s.parse();
            return docIde;
        } catch (Exception ex) {
            ex.toString();
            return "";
        }
        
    }
}
