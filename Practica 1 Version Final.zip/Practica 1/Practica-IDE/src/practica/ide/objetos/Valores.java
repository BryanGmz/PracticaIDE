/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Valores {
    private int valorNumerico;
    private String valor;
    private boolean cadena;
    
    public Valores(int valorNumerico, boolean cadena) {
        this.valorNumerico = valorNumerico;
        this.cadena = cadena;
    }
    //Si cadena = false -> es un identificador, cadena = true es una cadena     
    public Valores(String valor, boolean cadena) {
        this.valor = valor;
        this.cadena = cadena;
    }

    public int getValorNumerico() {
        return valorNumerico;
    }

    public void setValorNumerico(int valorNumerico) {
        this.valorNumerico = valorNumerico;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public boolean isCadena() {
        return cadena;
    }

    public void setCadena(boolean cadena) {
        this.cadena = cadena;
    }
    
}
