/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Objeto {
    private List<Valores> atributos;
    private boolean pasoCondiciones;
    private int indice;
    
    public Objeto(List<Valores> atributos) {
        this.atributos = atributos;
    }

    public List<Valores> getAtributos() {
        return atributos;
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public void setAtributos(List<Valores> atributos) {
        this.atributos = atributos;
    }

    public boolean isPasoCondiciones() {
        return pasoCondiciones;
    }

    public void setPasoCondiciones(boolean pasoCondiciones) {
        this.pasoCondiciones = pasoCondiciones;
    }
}
