/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Filtros {
    private int tipo;
    private List<Condicion> condiciones;
    private List<Filtros> fs;

    /*
        TIPO DE OPERADORES LOGICOS
        1. UNA SOLA CONDICION
        2. CONDICION AND's
        3. CONDICION OR's
    */
    public Filtros(int tipo, List<Condicion> condiciones) {
        this.tipo = tipo;
        this.condiciones = condiciones;
    }

    public List<Filtros> getFs() {
        return fs;
    }

    public void setFs(List<Filtros> fs) {
        this.fs = fs;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public List<Condicion> getCondiciones() {
        return condiciones;
    }

    public void setCondiciones(List<Condicion> condiciones) {
        this.condiciones = condiciones;
    }
}