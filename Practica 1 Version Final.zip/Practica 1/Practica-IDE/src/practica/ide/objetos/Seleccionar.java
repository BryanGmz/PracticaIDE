/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class Seleccionar extends Consultas{
    private List<Columnas> columnas;
    private List<Filtros> filtros;
    private Filtros filt;
    
    public Seleccionar(List<Columnas> columnas, List<Filtros> filtros, String nombreConsulta, String ubicacionConsulta) {
        super(nombreConsulta, ubicacionConsulta);
        this.columnas = columnas;
        this.filtros = filtros;
    }

    public Filtros getFilt() {
        return filt;
    }

    public void setFilt(Filtros filt) {
        this.filt = filt;
    }

    public List<Columnas> getColumnas() {
        return columnas;
    }

    public void setColumnas(List<Columnas> columnas) {
        this.columnas = columnas;
    }

    public List<Filtros> getFiltros() {
        return filtros;
    }

    public void setFiltros(List<Filtros> filtros) {
        this.filtros = filtros;
    }
}
