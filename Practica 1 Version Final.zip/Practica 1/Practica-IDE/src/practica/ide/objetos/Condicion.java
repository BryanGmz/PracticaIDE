/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ide.objetos;

/**
 *
 * @author USUARIO
 */
public class Condicion {
    private String columna;
    private int tipoCondicion;
    private String valor;
    private boolean cadena;
    private int valorNumerico;
    
    /*
        TIPO CONDICION:
            1 -> IGUAL
            2 -> MENOR
            3 -> MAYOR
            4 -> MENOR IGUAL
            5 -> MAYOR IGUAL
            6 -> MAYOR MENOR Diferentes
    */
    public Condicion(String columna, int tipoCondicion, String valor, boolean cadena) {
        this.columna = columna;
        this.tipoCondicion = tipoCondicion;
        this.valor = valor;
        this.cadena = cadena;
    }

    public Condicion(String columna, int tipoCondicion, int valorNumerico, boolean cadena) {
        this.columna = columna;
        this.tipoCondicion = tipoCondicion;
        this.cadena = cadena;
        this.valorNumerico = valorNumerico;
    }
    
    public int getValorNumerico() {
        return valorNumerico;
    }

    public void setValorNumerico(int valorNumerico) {
        this.valorNumerico = valorNumerico;
    }
    
    public String getColumna() {
        return columna;
    }

    public void setColumna(String columna) {
        this.columna = columna;
    }

    public int getTipoCondicion() {
        return tipoCondicion;
    }

    public void setTipoCondicion(int tipoCondicion) {
        this.tipoCondicion = tipoCondicion;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public boolean isCadena() {
        return cadena;
    }

    public void setCadena(boolean cadena) {
        this.cadena = cadena;
    }
    
}
